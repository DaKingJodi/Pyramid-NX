// Include the most common headers from the C standard library
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Include the main libnx system header, for Switch development
#include <switch.h>

// Main program entrypoint
int main(int argc, char *argv[]) {
  // This example uses a text console, as a simple way to output text to the
  // screen. If you want to write a software-rendered graphics application,
  //   take a look at the graphics/simplegfx example, which uses the libnx
  //   Framebuffer API instead.
  // If on the other hand you want to write an OpenGL based application,
  //   take a look at the graphics/opengl set of examples, which uses EGL
  //   instead.
  consoleInit(NULL);

  // Configure our supported input layout: a single player with standard
  // controller styles
  padConfigureInput(1, HidNpadStyleSet_NpadStandard);

  // Initialize the default gamepad (which reads handheld mode inputs as well as
  // the first connected controller)
  PadState pad;
  padInitializeDefault(&pad);
  const char *playerInput = "0";

  printf("Welcome to the Pyramid!\n\n");
  printf("how many decks do you want to choose:   \n\n");
  printf("Y = 1\n\n");
  printf("X = 2\n\n");
  printf("B = 3\n\n");
  printf("A = 4\n\n");

  // Main loop
  while (appletMainLoop()) {
    // Scan the gamepad. This should be done once for each frame
    padUpdate(&pad);

    // padGetButtonsDown returns the set of buttons that have been
    // newly pressed in this frame compared to the previous one
    u64 kDown = padGetButtonsDown(&pad);

    if (kDown & HidNpadButton_Plus)
      break; // break in order to return to hbmenu

    // Your code goes here
    if (kDown & HidNpadButton_Y)
      playerInput = "1";
    else if (kDown & HidNpadButton_X)
      playerInput = "2";
    else if (kDown & HidNpadButton_B)
      playerInput = "3";
    else if (kDown & HidNpadButton_A)
      playerInput = "4";
    if (strcmp(playerInput, "0") != 0){
    printf("You have chosen ");
    printf(playerInput);
    printf(" decks!\n\n");
    }
    playerInput = "0";
    // break;
    // Update the console, sending a new frame to the display
    consoleUpdate(NULL);
  }

  // Deinitialize and clean up resources used by the console (important!)
  consoleExit(NULL);
  return 0;
}
